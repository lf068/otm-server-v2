import {
  Client,
  GatewayIntentBits,
  SlashCommandBuilder,
  EmbedBuilder,
  MessageFlags,
  PermissionFlagsBits
} from 'discord.js'
import { config } from './config.js'
import { log } from './db.js'
import {
  createLicense,
  createMany,
  findByKey,
  effectiveStatus,
  licensesOfDiscord,
  resetHwid,
  setRevoked,
  setPassword,
  clearPassword,
  listLicenses,
  upsertUser,
  stats,
  normalize
} from './services/licenses.js'
import { attachDiscordClient, syncProfile } from './services/discord-profile.js'
import { createCheckout, mpEnabled } from './services/mercadopago.js'

export let client = null

const BRAND = 0x0f7bff
const PLANS = [
  { name: 'Vitalicia', value: 'lifetime' },
  { name: '30 dias', value: '30d' },
  { name: '90 dias', value: '90d' },
  { name: '365 dias', value: '365d' }
]

const isStaff = (i) => !!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)

const keysEmbed = (keys) =>
  new EmbedBuilder()
    .setColor(BRAND)
    .setTitle('✅ Licenca OTM liberada')
    .setDescription(
      'Obrigado pela compra!\n\n**Sua chave:**\n```\n' + keys.join('\n') + '\n```'
    )
    .addFields(
      {
        name: 'Como usar',
        value:
          '1) Baixe o OTM\n' +
          '2) Abra o `.exe` (aceite o Admin)\n' +
          '3) Cole a chave\n' +
          '4) **Crie sua senha** (voce escolhe)\n' +
          '5) Clique em Ativar'
      },
      {
        name: 'Sua senha',
        value:
          'A senha e **criada por voce** na primeira vez que abrir o app.\n' +
          'Guarde ela! Toda vez que abrir o OTM vai pedir **chave + senha**.\n' +
          'Esqueceu? Abra um ticket que a equipe reseta.'
      },
      { name: 'Download', value: config.downloadUrl }
    )
    .setFooter({ text: 'OTM • a chave fica vinculada a sua maquina (HWID)' })
    .setTimestamp()

async function giveCustomerRole(discordId) {
  if (!client || !config.discord.guildId || !config.discord.customerRoleId) return
  try {
    const guild = await client.guilds.fetch(config.discord.guildId)
    const member = await guild.members.fetch(discordId)
    await member.roles.add(config.discord.customerRoleId)
  } catch {
    /* membro saiu ou cargo invalido */
  }
}

/** Envia a chave na DM. Usado pelo webhook de pagamento e pelos comandos. */
export async function deliverLicense(discordId, keys) {
  if (!client) return { ok: false, message: 'Bot offline.' }
  if (!discordId) return { ok: false, message: 'Sem discord_id.' }
  try {
    const user = await client.users.fetch(discordId)
    await user.send({ embeds: [keysEmbed(keys)] })
    await giveCustomerRole(discordId)
    log('bot.dm_sent', { detail: { discordId, keys: keys.length } })
    return { ok: true }
  } catch (e) {
    log('bot.dm_failed', { detail: { discordId, error: e.message } })
    // avisa no canal de vendas para o suporte entregar na mao
    if (config.discord.salesChannelId) {
      try {
        const ch = await client.channels.fetch(config.discord.salesChannelId)
        await ch.send({
          content: `⚠️ Não consegui mandar DM para <@${discordId}>. Chave(s) para entrega manual:\n\`\`\`\n${keys.join('\n')}\n\`\`\``
        })
      } catch {
        /* ignora */
      }
    }
    return { ok: false, message: e.message }
  }
}

const commands = [
  new SlashCommandBuilder()
    .setName('comprar')
    .setDescription('Gera o link de pagamento da licenca OTM')
    .setDMPermission(true),

  new SlashCommandBuilder()
    .setName('minhakey')
    .setDescription('Recebe suas chaves no privado')
    .setDMPermission(true),

  new SlashCommandBuilder()
    .setName('status')
    .setDescription('Mostra o status de uma licenca')
    .addStringOption((o) => o.setName('key').setDescription('Sua chave OTM').setRequired(true)),

  new SlashCommandBuilder()
    .setName('resethwid')
    .setDescription('Libera a licenca para outra maquina (formatou o PC?)')
    .addStringOption((o) => o.setName('key').setDescription('Sua chave OTM').setRequired(true))
    .addStringOption((o) =>
      o.setName('motivo').setDescription('Motivo do reset').setRequired(false)
    ),

  new SlashCommandBuilder()
    .setName('gerar')
    .setDescription('[STAFF] Gera chaves novas')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addIntegerOption((o) =>
      o.setName('quantidade').setDescription('Quantas chaves').setRequired(true).setMinValue(1).setMaxValue(50)
    )
    .addStringOption((o) => o.setName('plano').setDescription('Tipo de licenca').addChoices(...PLANS))
    .addUserOption((o) => o.setName('usuario').setDescription('Enviar na DM deste membro')),

  new SlashCommandBuilder()
    .setName('revogar')
    .setDescription('[STAFF] Revoga ou reativa uma chave')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((o) => o.setName('key').setDescription('Chave').setRequired(true))
    .addBooleanOption((o) => o.setName('reativar').setDescription('Marcar como ativa de novo')),

  new SlashCommandBuilder()
    .setName('licencas')
    .setDescription('[STAFF] Lista as ultimas licencas')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((o) => o.setName('busca').setDescription('Chave, ID ou usuario')),

  new SlashCommandBuilder()
    .setName('setsenha')
    .setDescription('[STAFF] Define uma senha nova para o cliente')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((o) => o.setName('key').setDescription('Chave do cliente').setRequired(true))
    .addStringOption((o) =>
      o.setName('senha').setDescription('Nova senha (minimo 6 caracteres)').setRequired(true)
    ),

  new SlashCommandBuilder()
    .setName('resetsenha')
    .setDescription('[STAFF] Apaga a senha (o cliente cria outra no proximo login)')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((o) => o.setName('key').setDescription('Chave do cliente').setRequired(true)),

  new SlashCommandBuilder()
    .setName('vendas')
    .setDescription('[STAFF] Resumo de vendas e licencas')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
].map((c) => c.toJSON())

function row(lic) {
  const st = effectiveStatus(lic)
  const icon = st === 'active' ? '🟢' : st === 'revoked' ? '🔴' : '🟠'
  const hwid = lic.hwid ? `\`${String(lic.hwid).slice(0, 10)}…\`` : '_livre_'
  return `${icon} \`${lic.key}\` • ${lic.plan} • ${lic.discord_id ? `<@${lic.discord_id}>` : '_sem dono_'} • HWID ${hwid}`
}

async function handleInteraction(interaction) {
  if (!interaction.isChatInputCommand()) return
  const name = interaction.commandName

  try {
    // ---------------- publico ----------------
    if (name === 'comprar') {
      if (!mpEnabled()) {
        return interaction.reply({
          content: 'O pagamento automatico ainda nao esta ativo. Fale com a equipe de suporte para comprar.',
          flags: MessageFlags.Ephemeral
        })
      }
      const tag = interaction.user.username
      const pref = await createCheckout({ discordId: interaction.user.id, discordTag: tag })
      const url = pref.init_point || pref.sandbox_init_point

      try {
        await interaction.user.send({
          embeds: [
            new EmbedBuilder()
              .setColor(BRAND)
              .setTitle('Finalizar compra - OTM')
              .setDescription(
                `Pague no link abaixo (Pix ou cartao).\nAssim que o pagamento for aprovado, **sua chave chega aqui nesta DM automaticamente**.\n\n👉 ${url}`
              )
              .setFooter({ text: 'O link expira em alguns minutos. Use /comprar de novo se precisar.' })
          ]
        })
        return interaction.reply({ content: 'Te mandei o link no privado! 📩', flags: MessageFlags.Ephemeral })
      } catch {
        return interaction.reply({
          content: `Nao consegui te chamar no privado (DM fechada). Aqui esta o link:\n${url}`,
          flags: MessageFlags.Ephemeral
        })
      }
    }

    if (name === 'minhakey') {
      const list = licensesOfDiscord(interaction.user.id)
      if (!list.length) {
        return interaction.reply({
          content: 'Voce ainda nao tem nenhuma licenca OTM. Use `/comprar` para adquirir.',
          flags: MessageFlags.Ephemeral
        })
      }
      const keys = list.map((l) => `${l.key}   (${effectiveStatus(l)})`)
      try {
        await interaction.user.send({ embeds: [keysEmbed(list.map((l) => l.key))] })
        return interaction.reply({ content: 'Enviei suas chaves no privado! 📩', flags: MessageFlags.Ephemeral })
      } catch {
        return interaction.reply({
          content: 'DM fechada. Suas chaves:\n```\n' + keys.join('\n') + '\n```',
          flags: MessageFlags.Ephemeral
        })
      }
    }

    if (name === 'status') {
      const lic = findByKey(interaction.options.getString('key'))
      if (!lic) return interaction.reply({ content: '❌ Chave nao encontrada.', flags: MessageFlags.Ephemeral })
      const st = effectiveStatus(lic)
      const owner = lic.discord_id === interaction.user.id
      if (!owner && !isStaff(interaction))
        return interaction.reply({ content: '❌ Essa chave nao e sua.', flags: MessageFlags.Ephemeral })

      const profile = lic.discord_id ? await syncProfile(lic.discord_id) : null
      const embed = new EmbedBuilder()
        .setColor(BRAND)
        .setTitle('Status da licenca')
        .addFields(
          { name: 'Chave', value: `\`${lic.key}\`` },
          { name: 'Status', value: st === 'active' ? '🟢 Ativa' : st === 'revoked' ? '🔴 Revogada' : '🟠 Expirada' },
          { name: 'Plano', value: lic.plan },
          {
            name: 'Expira em',
            value: lic.expires_at ? new Date(lic.expires_at).toLocaleDateString('pt-BR') : 'Nunca (vitalicia)'
          },
          { name: 'Maquina vinculada', value: lic.hwid ? `\`${lic.hwid}\`` : '_ainda nao ativada_' },
          { name: 'Senha', value: lic.password_hash ? '🔒 criada' : '_nao criada ainda_' }
        )
      if (profile) embed.setThumbnail(profile.avatar || null)
      return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral })
    }

    if (name === 'resethwid') {
      const lic = findByKey(interaction.options.getString('key'))
      if (!lic) return interaction.reply({ content: '❌ Chave nao encontrada.', flags: MessageFlags.Ephemeral })
      if (lic.discord_id !== interaction.user.id && !isStaff(interaction))
        return interaction.reply({ content: '❌ Essa chave nao e sua.', flags: MessageFlags.Ephemeral })

      const r = resetHwid(lic.key)
      log('bot.reset_hwid', {
        key: lic.key,
        detail: { by: interaction.user.id, motivo: interaction.options.getString('motivo') }
      })
      return interaction.reply({
        content: `✅ ${r.message}\nAgora e so abrir o app no PC novo e ativar de novo.`,
        flags: MessageFlags.Ephemeral
      })
    }

    // ---------------- staff ----------------
    if (name === 'gerar') {
      const amount = interaction.options.getInteger('quantidade')
      const plan = interaction.options.getString('plano') || 'lifetime'
      const target = interaction.options.getUser('usuario')

      const created = createMany(amount, {
        plan,
        discordId: target?.id || null,
        discordTag: target?.username || null
      })

      if (target) await deliverLicense(target.id, created.map((c) => c.key))

      return interaction.reply({
        content: `Geradas **${created.length}** chave(s)${target ? ` para ${target}` : ''}:\n\`\`\`\n${created
          .map((c) => c.key)
          .join('\n')}\n\`\`\``,
        flags: MessageFlags.Ephemeral
      })
    }

    if (name === 'revogar') {
      const key = interaction.options.getString('key')
      const reactivate = interaction.options.getBoolean('reativar') || false
      const r = setRevoked(key, !reactivate)
      return interaction.reply({ content: r.ok ? `✅ ${r.message}` : `❌ ${r.message}`, flags: MessageFlags.Ephemeral })
    }

    if (name === 'setsenha') {
      const key = interaction.options.getString('key')
      const senha = interaction.options.getString('senha')
      const r = setPassword(key, senha)
      if (r.ok && !isStaff(interaction)) {
        // nao deveria acontecer (comando e staff), mas evita vazar a senha
        return interaction.reply({ content: '✅ Senha atualizada.', flags: MessageFlags.Ephemeral })
      }
      return interaction.reply({
        content: r.ok
          ? `✅ ${r.message}\nAvise o cliente da nova senha por um canal privado.`
          : `❌ ${r.message}`,
        flags: MessageFlags.Ephemeral
      })
    }

    if (name === 'resetsenha') {
      const key = interaction.options.getString('key')
      const r = clearPassword(key)
      return interaction.reply({
        content: r.ok
          ? `✅ ${r.message}\nEle so precisa abrir o app, colocar a chave e criar a senha de novo.`
          : `❌ ${r.message}`,
        flags: MessageFlags.Ephemeral
      })
    }

    if (name === 'licencas') {
      const list = listLicenses({ search: interaction.options.getString('busca') || '', limit: 15 })
      if (!list.length) return interaction.reply({ content: 'Nenhuma licenca encontrada.', flags: MessageFlags.Ephemeral })
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(BRAND)
            .setTitle('Ultimas licencas')
            .setDescription(list.map(row).join('\n'))
        ],
        flags: MessageFlags.Ephemeral
      })
    }

    if (name === 'vendas') {
      const s = stats()
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(BRAND)
            .setTitle('📊 Resumo OTM')
            .addFields(
              { name: 'Chaves geradas', value: String(s.total), inline: true },
              { name: 'Ativas', value: String(s.active), inline: true },
              { name: 'Revogadas', value: String(s.revoked), inline: true },
              { name: 'Ativadas (HWID)', value: String(s.bound), inline: true },
              { name: 'Vendas aprovadas', value: String(s.approvedOrders), inline: true }
            )
        ],
        flags: MessageFlags.Ephemeral
      })
    }
  } catch (e) {
    log('bot.error', { detail: { command: name, error: e.message } })
    const msg = { content: `⚠️ Erro: ${e.message}`, flags: MessageFlags.Ephemeral }
    if (interaction.replied || interaction.deferred) interaction.followUp(msg).catch(() => {})
    else interaction.reply(msg).catch(() => {})
  }
}

export async function startBot() {
  if (!config.discord.enabled) return null
  if (!config.discord.token || !config.discord.clientId) {
    console.log('[bot] DISCORD_TOKEN/DISCORD_CLIENT_ID ausentes - bot desativado')
    return null
  }

  client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.DirectMessages]
  })
  attachDiscordClient(client)

  client.once('ready', async () => {
    console.log(`[bot] online como ${client.user.tag}`)
    client.user.setActivity('OTM • /comprar', { type: 3 })
    try {
      if (config.discord.guildId) {
        const guild = await client.guilds.fetch(config.discord.guildId)
        await guild.commands.set(commands)
        console.log('[bot] comandos registrados no servidor')
      } else {
        await client.application.commands.set(commands)
        console.log('[bot] comandos registrados globalmente')
      }
    } catch (e) {
      console.error('[bot] falha ao registrar comandos:', e.message)
    }
  })

  client.on('interactionCreate', handleInteraction)
  client.on('error', (e) => console.error('[bot] erro:', e.message))

  await client.login(config.discord.token)
  return client
}
