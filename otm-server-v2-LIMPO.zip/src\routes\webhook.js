import { db, log } from '../db.js'
import { config } from '../config.js'
import { createLicense } from '../services/licenses.js'
import { createCheckout, getPayment, verifyWebhookSignature, mpEnabled } from '../services/mercadopago.js'
import { deliverLicense } from '../bot.js'

function getOrder(providerId) {
  return db.prepare('SELECT * FROM orders WHERE provider_id = ?').get(String(providerId))
}

function insertOrder(o) {
  const info = db
    .prepare(
      `INSERT OR IGNORE INTO orders (provider, provider_id, discord_id, discord_tag, amount, status, license_key, created_at)
       VALUES (?,?,?,?,?,?,?,?)`
    )
    .run(o.provider, String(o.providerId), o.discordId, o.discordTag, o.amount, o.status, o.licenseKey, Date.now())
  return info.changes > 0
}

function updateOrder(providerId, fields) {
  const keys = Object.keys(fields)
  if (!keys.length) return
  const sets = keys.map((k) => `${k} = ?`).join(', ')
  db.prepare(`UPDATE orders SET ${sets} WHERE provider_id = ?`).run(
    ...keys.map((k) => fields[k]),
    String(providerId)
  )
}

/** Cria a chave e entrega na DM. Idempotente por provider_id. */
async function handlePayment(payment) {
  const providerId = String(payment.id)
  const status = payment.status
  const discordId =
    payment.external_reference || payment.metadata?.discord_id || payment.payer?.id || null
  const discordTag = payment.metadata?.discord_tag || null
  const amount = payment.transaction_amount ?? null

  const existing = getOrder(providerId)

  if (existing && existing.status === 'approved' && existing.license_key) return

  if (!existing) {
    insertOrder({
      provider: 'mercadopago',
      providerId,
      discordId,
      discordTag,
      amount,
      status,
      licenseKey: null
    })
  } else {
    updateOrder(providerId, { status, amount, discord_id: discordId })
  }

  log('mp.payment', { detail: { providerId, status, discordId } })

  if (status !== 'approved') return

  const lic = createLicense({
    plan: 'lifetime',
    discordId,
    discordTag,
    note: `Mercado Pago ${providerId}`
  })

  updateOrder(providerId, { status: 'approved', license_key: lic.key })

  if (discordId) await deliverLicense(discordId, [lic.key])

  if (config.discord.salesChannelId && config.discord.enabled) {
    // aviso interno (best effort)
    try {
      const { client } = await import('../bot.js')
      const ch = await client?.channels?.fetch(config.discord.salesChannelId)
      await ch?.send(
        `💰 Nova venda aprovada! **R$ ${Number(amount || 0).toFixed(2)}** • ${
          discordId ? `<@${discordId}>` : 'sem discord'
        } • \`${lic.key}\``
      )
    } catch {
      /* ignora */
    }
  }
}

export default async function webhookRoutes(app) {
  /** Gera o link de pagamento (usado pelo bot e por um site). */
  app.post('/api/checkout', async (req, reply) => {
    const { discordId, discordTag = '' } = req.body || {}
    if (!discordId) return reply.code(400).send({ ok: false, message: 'Informe discordId.' })
    if (!mpEnabled()) return reply.code(503).send({ ok: false, message: 'Mercado Pago nao configurado.' })

    try {
      const pref = await createCheckout({ discordId, discordTag })
      log('mp.checkout', { detail: { discordId, pref: pref.id } })
      return reply.send({
        ok: true,
        id: pref.id,
        url: pref.init_point || pref.sandbox_init_point
      })
    } catch (e) {
      log('mp.checkout_error', { detail: { error: e.message } })
      return reply.code(502).send({ ok: false, message: e.message })
    }
  })

  /** Webhook do Mercado Pago. */
  app.post('/webhook/mercadopago', async (req, reply) => {
    const q = req.query || {}
    const body = req.body || {}
    const type = body.type || body.topic || q.type || q.topic
    const dataId = body?.data?.id || q['data.id'] || q.id

    if (!verifyWebhookSignature(req.headers, dataId)) {
      log('mp.bad_signature', { detail: { dataId } })
      return reply.code(401).send({ ok: false })
    }

    // responde 200 imediatamente (obrigatorio)
    reply.send({ ok: true })

    if (String(type) !== 'payment' || !dataId) return

    try {
      const payment = await getPayment(dataId)
      await handlePayment(payment)
    } catch (e) {
      log('mp.webhook_error', { detail: { dataId, error: e.message } })
      console.error('[mp] erro ao processar pagamento', dataId, e.message)
    }
  })

  app.get('/obrigado', async (_req, reply) =>
    reply.type('text/html').send(
      `<!doctype html><meta charset="utf-8"><title>Obrigado!</title>
       <body style="background:#0a0f1a;color:#fff;font-family:system-ui;display:grid;place-items:center;height:100vh;margin:0">
       <div style="text-align:center">
         <h1 style="color:#0F7BFF">Pagamento recebido!</h1>
         <p>Sua chave chega no <strong>privado do Discord</strong> em instantes.</p>
       </div></body>`
    ))
}
