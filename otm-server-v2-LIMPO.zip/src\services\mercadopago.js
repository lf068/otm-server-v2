import crypto from 'node:crypto'
import { config } from '../config.js'

const API = 'https://api.mercadopago.com'

export const mpEnabled = () =>
  config.mercadopago.enabled && !!config.mercadopago.accessToken

function authHeaders() {
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${config.mercadopago.accessToken}`
  }
}

/**
 * Cria um link de pagamento (Checkout Pro) amarrado ao discord_id do comprador.
 * O external_reference e o que liga o pagamento a pessoa.
 */
export async function createCheckout({ discordId, discordTag = '' }) {
  const body = {
    items: [
      {
        title: config.mercadopago.title,
        description: 'Licenca com vinculacao por maquina (HWID). Envio automatico pelo Discord.',
        quantity: 1,
        currency_id: 'BRL',
        unit_price: config.mercadopago.price
      }
    ],
    external_reference: String(discordId || ''),
    notification_url: `${config.publicUrl}/webhook/mercadopago`,
    metadata: { discord_id: String(discordId || ''), discord_tag: discordTag || '' },
    statement_descriptor: 'OTM'
  }

  const res = await fetch(`${API}/checkout/preferences`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(body)
  })

  if (!res.ok) throw new Error(`Mercado Pago ${res.status}: ${await res.text()}`)
  return res.json()
}

export async function getPayment(paymentId) {
  const res = await fetch(`${API}/v1/payments/${paymentId}`, { headers: authHeaders() })
  if (!res.ok) throw new Error(`Mercado Pago ${res.status}: ${await res.text()}`)
  return res.json()
}

/**
 * Valida a assinatura do webhook (x-signature).
 * Se MP_WEBHOOK_SECRET nao estiver configurado, retorna true (modo simples).
 */
export function verifyWebhookSignature(headers, dataId) {
  const secret = config.mercadopago.webhookSecret
  if (!secret) return true

  const signature = headers['x-signature']
  const requestId = headers['x-request-id']
  if (!signature) return false

  const parts = Object.fromEntries(
    String(signature)
      .split(',')
      .map((p) => p.split('=').map((s) => s.trim()))
  )
  const ts = parts.ts
  const v1 = parts.v1
  if (!ts || !v1) return false

  const manifest = `id:${String(dataId).toLowerCase()};request-id:${requestId};ts:${ts};`
  const hmac = crypto.createHmac('sha256', secret).update(manifest).digest('hex')

  try {
    return crypto.timingSafeEqual(Buffer.from(hmac), Buffer.from(String(v1)))
  } catch {
    return false
  }
}
