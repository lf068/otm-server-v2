import Database from 'better-sqlite3'
import { mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { config } from './config.js'

const file = resolve(config.dbFile)
mkdirSync(dirname(file), { recursive: true })

export const db = new Database(file)
db.pragma('journal_mode = WAL')

db.exec(`
CREATE TABLE IF NOT EXISTS licenses (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  key           TEXT UNIQUE NOT NULL,
  password_hash TEXT,
  password_set_at INTEGER,
  discord_id    TEXT,
  discord_tag   TEXT,
  discord_name  TEXT,
  discord_avatar TEXT,
  avatar_synced_at INTEGER,
  hwid          TEXT,
  plan          TEXT NOT NULL DEFAULT 'lifetime',
  status        TEXT NOT NULL DEFAULT 'active',
  expires_at    INTEGER,
  created_at    INTEGER NOT NULL,
  activated_at  INTEGER,
  last_seen_at  INTEGER,
  note          TEXT
);
CREATE INDEX IF NOT EXISTS idx_lic_discord ON licenses(discord_id);

CREATE TABLE IF NOT EXISTS users (
  discord_id   TEXT PRIMARY KEY,
  username     TEXT,
  global_name  TEXT,
  avatar       TEXT,
  updated_at   INTEGER
);

CREATE TABLE IF NOT EXISTS orders (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  provider      TEXT NOT NULL,
  provider_id   TEXT UNIQUE,
  discord_id    TEXT,
  discord_tag   TEXT,
  amount        REAL,
  status        TEXT,
  license_key   TEXT,
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS logs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  ts            INTEGER NOT NULL,
  event         TEXT NOT NULL,
  license_key   TEXT,
  hwid          TEXT,
  detail        TEXT
);
`)

/**
 * Migracoes: adiciona colunas novas em bancos que ja existem
 * (importante porque o banco fica no volume do Railway).
 */
function ensureColumn(table, column, ddl) {
  try {
    const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name)
    if (!cols.includes(column)) {
      db.exec(`ALTER TABLE ${table} ADD COLUMN ${ddl}`)
      console.log(`[db] coluna adicionada: ${table}.${column}`)
    }
  } catch (e) {
    console.error(`[db] falha na migracao ${table}.${column}:`, e.message)
  }
}

ensureColumn('licenses', 'password_hash', 'password_hash TEXT')
ensureColumn('licenses', 'password_set_at', 'password_set_at INTEGER')

export function log(event, { key = null, hwid = null, detail = null } = {}) {
  try {
    db.prepare('INSERT INTO logs (ts, event, license_key, hwid, detail) VALUES (?,?,?,?,?)').run(
      Date.now(),
      event,
      key,
      hwid,
      detail ? JSON.stringify(detail) : null
    )
  } catch {
    /* log nunca deve derrubar a API */
  }
}

export const now = () => Date.now()
