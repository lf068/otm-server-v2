import 'dotenv/config'

const bool = (v, d = false) => (v === undefined ? d : String(v).toLowerCase() === 'true')

export const config = {
  port: Number(process.env.PORT || 8080),
  host: process.env.HOST || '0.0.0.0',
  publicUrl: process.env.PUBLIC_URL || 'http://localhost:8080',

  // Segredo do painel admin (gere um aleatorio longo)
  adminToken: process.env.ADMIN_TOKEN || 'TROQUE-ESTE-TOKEN-AGORA',

  // Link de download enviado na DM
  downloadUrl: process.env.DOWNLOAD_URL || 'https://exemplo.com/OTM.exe',

  dbFile: process.env.DB_FILE || './data/otm.db',

  license: {
    keyPrefix: process.env.KEY_PREFIX || 'OTM',
    // dias que o app continua funcionando sem internet
    offlineGraceDays: Number(process.env.OFFLINE_GRACE_DAYS || 3)
  },

  discord: {
    token: process.env.DISCORD_TOKEN || '',
    clientId: process.env.DISCORD_CLIENT_ID || '',
    guildId: process.env.DISCORD_GUILD_ID || '',
    // cargos (opcional)
    customerRoleId: process.env.CUSTOMER_ROLE_ID || '',
    staffRoleId: process.env.STAFF_ROLE_ID || '',
    // canal onde o bot avisa novas vendas (opcional)
    salesChannelId: process.env.SALES_CHANNEL_ID || '',
    enabled: bool(process.env.DISCORD_ENABLED, true)
  },

  mercadopago: {
    accessToken: process.env.MP_ACCESS_TOKEN || '',
    webhookSecret: process.env.MP_WEBHOOK_SECRET || '',
    price: Number(process.env.MP_PRICE || 49.9),
    title: process.env.MP_TITLE || 'OTM - Painel de Otimizacao (Licenca)',
    enabled: bool(process.env.MP_ENABLED, false)
  }
}
