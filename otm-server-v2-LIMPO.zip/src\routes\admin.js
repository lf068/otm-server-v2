import { config } from '../config.js'
import {
  createMany,
  resetHwid,
  setRevoked,
  setPassword,
  clearPassword,
  bindDiscord,
  listLicenses,
  stats,
  findByKey,
  effectiveStatus
} from '../services/licenses.js'
import { syncProfile, profilePayload } from '../services/discord-profile.js'
import { deliverLicense } from '../bot.js'

function guard(req, reply) {
  const token = req.headers['x-admin-token'] || req.headers['authorization']?.replace(/^Bearer /, '')
  if (!token || token !== config.adminToken) {
    reply.code(401).send({ ok: false, message: 'Token de admin invalido.' })
    return false
  }
  if (config.adminToken === 'TROQUE-ESTE-TOKEN-AGORA') {
    reply.code(500).send({ ok: false, message: 'Configure ADMIN_TOKEN no .env antes de usar o painel.' })
    return false
  }
  return true
}

export default async function adminRoutes(app) {
  app.addHook('preHandler', async (req, reply) => {
    if (!req.url.startsWith('/api/admin')) return
    guard(req, reply)
  })

  /** Gera chaves. Envia na DM se discordId for informado. */
  app.post('/api/admin/keys', async (req, reply) => {
    const { amount = 1, plan = 'lifetime', discordId = null, discordTag = null, note = null, send = false } =
      req.body || {}

    const created = createMany(Math.min(Math.max(Number(amount) || 1, 1), 200), {
      plan,
      discordId,
      discordTag,
      note
    })

    let delivery = null
    if (send && discordId) delivery = await deliverLicense(discordId, created.map((c) => c.key))

    return reply.send({
      ok: true,
      keys: created.map((c) => c.key),
      delivery
    })
  })

  app.post('/api/admin/reset-hwid', async (req, reply) => {
    const { key } = req.body || {}
    if (!key) return reply.code(400).send({ ok: false, message: 'Informe a chave.' })
    const lic = findByKey(key)
    if (!lic) return reply.code(404).send({ ok: false, message: 'Chave nao encontrada.' })
    return reply.send(resetHwid(key))
  })

  app.post('/api/admin/revoke', async (req, reply) => {
    const { key, revoked = true } = req.body || {}
    if (!key) return reply.code(400).send({ ok: false, message: 'Informe a chave.' })
    return reply.send(setRevoked(key, !!revoked))
  })

  /** Suporte: define uma senha nova para o cliente. */
  app.post('/api/admin/set-password', async (req, reply) => {
    const { key, password } = req.body || {}
    if (!key || !password) return reply.code(400).send({ ok: false, message: 'Informe key e password.' })
    return reply.send(setPassword(key, String(password)))
  })

  /** Suporte: apaga a senha (o cliente cria uma nova no proximo login). */
  app.post('/api/admin/reset-password', async (req, reply) => {
    const { key } = req.body || {}
    if (!key) return reply.code(400).send({ ok: false, message: 'Informe a chave.' })
    return reply.send(clearPassword(key))
  })

  app.post('/api/admin/bind', async (req, reply) => {
    const { key, discordId, discordTag = null } = req.body || {}
    if (!key || !discordId) return reply.code(400).send({ ok: false, message: 'Informe key e discordId.' })
    await syncProfile(discordId, { force: true })
    return reply.send(bindDiscord(key, discordId, discordTag))
  })

  app.get('/api/admin/licenses', async (req, reply) => {
    const { search = '', limit = 100, offset = 0 } = req.query || {}
    const list = listLicenses({ search, limit: Number(limit), offset: Number(offset) })
    return reply.send({
      ok: true,
      total: stats().total,
      licenses: list.map((l) => ({
        key: l.key,
        status: effectiveStatus(l),
        plan: l.plan,
        discordId: l.discord_id,
        discordTag: l.username,
        avatar: l.avatar,
        hwid: l.hwid,
        hasPassword: !!l.password_hash,
        created_at: l.created_at,
        activated_at: l.activated_at,
        expires_at: l.expires_at
      }))
    })
  })

  app.get('/api/admin/stats', async (_req, reply) => reply.send({ ok: true, ...stats() }))

  /** Forca a atualizacao do nome/avatar de um usuario. */
  app.post('/api/admin/sync-profile', async (req, reply) => {
    const { discordId } = req.body || {}
    if (!discordId) return reply.code(400).send({ ok: false, message: 'Informe discordId.' })
    await syncProfile(discordId, { force: true })
    return reply.send({ ok: true, profile: profilePayload(discordId) })
  })
}
