import crypto from 'node:crypto'

const KEYLEN = 64
const MIN_LEN = 6
const MAX_LEN = 64

/** Gera o hash da senha (scrypt + salt aleatorio). Formato: scrypt$saltHex$hashHex */
export function hashPassword(password) {
  const salt = crypto.randomBytes(16)
  const hash = crypto.scryptSync(String(password), salt, KEYLEN)
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`
}

/** Compara a senha digitada com o hash guardado. */
export function verifyPassword(password, stored) {
  if (!stored || !password) return false
  const parts = String(stored).split('$')
  if (parts.length !== 3 || parts[0] !== 'scrypt') return false

  const salt = Buffer.from(parts[1], 'hex')
  const expected = Buffer.from(parts[2], 'hex')
  if (!salt.length || !expected.length) return false

  try {
    const actual = crypto.scryptSync(String(password), salt, expected.length)
    return crypto.timingSafeEqual(actual, expected)
  } catch {
    return false
  }
}

export function isValidPassword(password) {
  const p = String(password || '')
  return p.length >= MIN_LEN && p.length <= MAX_LEN
}

export const PASSWORD_RULES = `A senha precisa ter entre ${MIN_LEN} e ${MAX_LEN} caracteres.`
