import { getUser, upsertUser } from './licenses.js'

let client = null

export function attachDiscordClient(c) {
  client = c
}

const SIX_HOURS = 6 * 60 * 60 * 1000

/**
 * Busca o perfil atualizado no Discord (nome + avatar) e guarda em cache.
 * Funciona quando o bot compartilha um servidor com o usuario.
 */
export async function syncProfile(discordId, { force = false } = {}) {
  if (!discordId) return null

  const cached = getUser(discordId)
  if (cached && !force && Date.now() - (cached.updated_at || 0) < SIX_HOURS) return cached

  if (client) {
    try {
      const user = await client.users.fetch(discordId, { force: true })
      upsertUser({
        id: user.id,
        username: user.username,
        globalName: user.globalName || user.username,
        avatar: user.displayAvatarURL({ size: 256, extension: 'png' })
      })
    } catch {
      /* bot fora do servidor ou sem cache - mantem o que ja temos */
    }
  }

  return getUser(discordId)
}

/** Formato consumido pelo app OTM. */
export function profilePayload(discordId) {
  if (!discordId) return null
  const u = getUser(discordId)
  if (!u) return null
  return {
    id: u.discord_id,
    username: u.username,
    globalName: u.global_name || u.username,
    tag: u.username ? `@${u.username}` : null,
    avatar: u.avatar
  }
}
