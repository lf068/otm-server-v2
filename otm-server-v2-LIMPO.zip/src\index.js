import Fastify from 'fastify'
import cors from '@fastify/cors'
import { config } from './config.js'
import { stats } from './services/licenses.js'
import publicRoutes from './routes/public.js'
import adminRoutes from './routes/admin.js'
import webhookRoutes from './routes/webhook.js'
import { startBot } from './bot.js'

const app = Fastify({ logger: false, trustProxy: true })

await app.register(cors, { origin: true })

app.get('/', async () => ({
  name: 'OTM License Server',
  status: 'online',
  stats: stats(),
  mercadopago: config.mercadopago.enabled ? 'ativo' : 'desativado',
  discord: config.discord.token ? 'configurado' : 'desativado',
  ts: Date.now()
}))

await app.register(publicRoutes)
await app.register(adminRoutes)
await app.register(webhookRoutes)

app.setErrorHandler((err, _req, reply) => {
  console.error('[api] erro:', err.message)
  reply.code(err.statusCode || 500).send({ ok: false, message: err.message })
})

try {
  await app.listen({ port: config.port, host: config.host })
  console.log(`[api] ouvindo em http://${config.host}:${config.port}`)
  console.log(`[api] URL publica configurada: ${config.publicUrl}`)
} catch (e) {
  console.error('[api] falha ao subir:', e.message)
  process.exit(1)
}

startBot().catch((e) => console.error('[bot] falhou ao iniciar:', e.message))

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, async () => {
    try {
      await app.close()
    } catch {
      /* ignora */
    }
    process.exit(0)
  })
}
