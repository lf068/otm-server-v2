# Como subir o OTM Server no Railway

## 1) Preparo do repositório
Você vai subir a pasta `otm-server/` como um repositório no GitHub (mais fácil pro Railway).

No terminal dentro de `otm-server/` (use Git Bash, PowerShell, etc):

```bash
git init
git add .
git commit -m "otm server first commit"
```

Crie um repositório novo no GitHub (sem README, sem .gitignore). Depois:

```bash
git remote add origin https://github.com/SEU_USUARIO/SEU_REPO.git
git branch -M main
git push -u origin main
```

## 2) Criar projeto no Railway

1. Acesse [railway.app](https://railway.app/)
2. Faça login com sua conta (pode ser GitHub)
3. Clique em **"New Project"** → **"Deploy from GitHub repo"**
4. Selecione o repositório `otm-server` que você acabou de criar
5. Aguarde o primeiro deploy começar

## 3) Adicionar Volume (persistir o banco SQLite)

O banco fica em `data/otm.db`. Sem volume, ele **some** a cada deploy novo.

1. Na aba do seu projeto, clique em **"Variables"** não. Vai na aba **"Settings"**? Melhor: na tela do serviço, clique em **"Volumes"** → **"Add Volume"**
2. **Mount Path:** digite exatamente: `/data`
3. Tamanho padrão (1GB) já basta
4. Clique em **"Add"**

Obs: O `.env` já tem `DB_FILE=./data/otm.db`. Com volume montado em `/data`, vai funcionar certinho.

## 4) Configurar as variáveis de ambiente

Vá em **"Variables"** → **"Add Variable"** e adicione **uma por uma**.

### Essenciais
- `ADMIN_TOKEN` → gere um token forte (ex: use [randomkeygen.com](https://randomkeygen.com/))
- `PUBLIC_URL` → vamos preencher depois (passo 5), mas pode deixar vazio por enquanto ou colocar `http://localhost:8080` temporário
- `DOWNLOAD_URL` → link do seu `.exe` (pode ser um link direto do Google Drive/Dropbox com download direto, ou link do seu site)

### Discord
- `DISCORD_ENABLED` → `true`
- `DISCORD_TOKEN` → token do seu bot (Developer Portal → Bot → Reset Token)
- `DISCORD_CLIENT_ID` → Application ID (General Information)
- `DISCORD_GUILD_ID` → ID do seu servidor do Discord (Ative Modo Desenvolvedor → clique com botão direito no servidor → Copiar ID do Servidor)
- `CUSTOMER_ROLE_ID` → (opcional) ID do cargo que será dado ao cliente
- `SALES_CHANNEL_ID` → (opcional) ID do canal pra avisar falha de DM

### Mercado Pago (pra entrega automática da key)
- `MP_ENABLED` → `true`
- `MP_ACCESS_TOKEN` → em [Mercado Pago Developers](https://www.mercadopago.com.br/developers/) → Suas integrações → Credenciais → **Token de acesso** (produção)
- `MP_WEBHOOK_SECRET` → opcional mas recomendado (Webhook → Assinatura)
- `MP_PRICE` → `49.90`
- `MP_TITLE` → pode deixar como está

### Demais (padrões já ok)
- `PORT` → geralmente o Railway preenche sozinho. Não precisa mexer
- `HOST` → `0.0.0.0`
- `OFFLINE_GRACE_DAYS` → `3`
- `KEY_PREFIX` → `OTM`

## 5) Pegar a URL pública e configurar PUBLIC_URL

1. Vá em **"Settings"** → **"Domains"**
2. Clique em **"Generate Domain"** (Railway gera algo tipo `seu-projeto.up.railway.app`)
3. Copie essa URL
4. Volte em **"Variables"**, edite `PUBLIC_URL` e cole exatamente essa URL (sem `/` no final)
5. Salve. O Railway vai fazer um **redeploy automático**

## 6) Registrar os comandos do Discord

Depois que o bot subir com sucesso, os **slash commands** (`/comprar`, `/gerar`, etc) são registrados.

Pra garantir, você pode reiniciar o serviço: **"Deployments"** → ⋮ (três pontos) → **"Redeploy"**.

## 7) Testar o servidor

Abra no navegador:
```
https://sua-url.up.railway.app/
```

Deve aparecer algo assim:
```json
{"name":"OTM License Server","status":"online","mercadopago":"ativo","discord":"configurado",...}
```

## 8) Apontar o app OTM pra esse servidor

1. Abra o **OTM.exe** (aplicativo desktop)
2. Na tela de login, clique em **"Configurar servidor de licenças"** (embaixo)
3. Cole a URL: `https://sua-url.up.railway.app`
4. Clique em **"Testar"** → deve aparecer **"Conectado • latência Xms"**
5. Pronto! Agora você pode gerar chaves pelo Discord (`/gerar`) e testar a ativação

## 9) (Opcional mas útil) Configurar webhook do Mercado Pago

No [Mercado Pago Developers](https://www.mercadopago.com.br/developers/):
1. Integrações → Webhooks
2. URL de notificação: `https://sua-url.up.railway.app/webhook/mercadopago`
3. Eventos: marque **"Pagamentos"** (`payment`)
4. Salvar

Assim o bot entrega a chave **automaticamente** no DM assim que o Pix/cartão for aprovado.

## Dica prática

**Não** mude o nome da pasta raiz. Mantenha `otm-server/` com `src/index.js`, `package.json`, `Procfile` e `railway.json` exatamente assim.

Se der algum erro no deploy, me envie o **log** do Railway (Deployments → View Logs). Te ajudo a corrigir na hora.
