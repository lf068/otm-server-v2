import crypto from 'node:crypto'
import { db, log, now } from '../db.js'
import { config } from '../config.js'
import { hashPassword, verifyPassword, isValidPassword } from './passwords.js'

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

function segment(n = 4) {
  const bytes = crypto.randomBytes(n)
  let s = ''
  for (let i = 0; i < n; i++) s += ALPHABET[bytes[i] % ALPHABET.length]
  return s
}

export function generateKey() {
  return `${config.license.keyPrefix}-${segment(4)}-${segment(4)}-${segment(4)}-${segment(4)}`
}

const DURATIONS = {
  lifetime: null,
  '30d': 30,
  '90d': 90,
  '365d': 365
}

export function planDurationMs(plan) {
  const days = DURATIONS[plan]
  if (days === undefined) return null
  return days === null ? null : days * 24 * 60 * 60 * 1000
}

export function findByKey(key) {
  return db.prepare('SELECT * FROM licenses WHERE key = ?').get(normalize(key))
}

export function normalize(key) {
  return String(key || '').trim().toUpperCase()
}

export function createLicense({ plan = 'lifetime', discordId = null, discordTag = null, note = null } = {}) {
  let key = generateKey()
  let guard = 0
  while (findByKey(key) && guard++ < 20) key = generateKey()

  const created = now()
  const expiresAt = planDurationMs(plan) ? created + planDurationMs(plan) : null

  db.prepare(
    `INSERT INTO licenses (key, discord_id, discord_tag, plan, status, expires_at, created_at, note)
     VALUES (?,?,?,?,'active',?,?,?)`
  ).run(key, discordId, discordTag, plan, expiresAt, created, note)

  log('license.created', { key, detail: { plan, discordId } })
  return findByKey(key)
}

export function createMany(amount, opts = {}) {
  const out = []
  for (let i = 0; i < amount; i++) out.push(createLicense(opts))
  return out
}

export function isExpired(lic) {
  return !!(lic.expires_at && lic.expires_at < now())
}

export function effectiveStatus(lic) {
  if (!lic) return 'not_found'
  if (lic.status === 'revoked') return 'revoked'
  if (isExpired(lic)) return 'expired'
  return 'active'
}

/**
 * Checagem da senha. Retorna null quando esta tudo certo, ou o erro.
 * - Licenca sem senha -> pede para criar (NEED_PASSWORD)
 * - Licenca com senha -> exige a senha correta
 */
function checkPassword(lic, password) {
  if (!lic.password_hash) {
    if (!password) {
      return {
        ok: false,
        code: 'NEED_PASSWORD',
        message: 'Esta chave ainda nao tem senha. Crie uma senha para ela.'
      }
    }
    if (!isValidPassword(password)) {
      return { ok: false, code: 'WEAK_PASSWORD', message: 'A senha precisa ter no minimo 6 caracteres.' }
    }
    db.prepare('UPDATE licenses SET password_hash = ?, password_set_at = ? WHERE id = ?').run(
      hashPassword(password),
      now(),
      lic.id
    )
    log('license.password_set', { key: lic.key })
    return null
  }

  if (!password) {
    return { ok: false, code: 'PASSWORD_REQUIRED', message: 'Digite a senha da sua licenca.' }
  }
  if (!verifyPassword(password, lic.password_hash)) {
    log('license.wrong_password', { key: lic.key })
    return { ok: false, code: 'WRONG_PASSWORD', message: 'Senha incorreta.' }
  }
  return null
}

/**
 * Ativa (primeira vez) ou valida uma licenca.
 * Ordem: chave -> status -> HWID -> senha -> vincula.
 */
export function activate(key, hwid, password = '', meta = {}) {
  const lic = findByKey(key)
  if (!lic) {
    log('activate.invalid', { key: normalize(key), hwid })
    return { ok: false, code: 'INVALID_KEY', message: 'Chave nao encontrada.' }
  }

  const status = effectiveStatus(lic)
  if (status === 'revoked') {
    log('activate.revoked', { key: lic.key, hwid })
    return { ok: false, code: 'REVOKED', message: 'Esta chave foi revogada.' }
  }
  if (status === 'expired') {
    log('activate.expired', { key: lic.key, hwid })
    return { ok: false, code: 'EXPIRED', message: 'Esta licenca expirou.' }
  }

  // Maquina errada? Nem chega a mexer na senha.
  if (lic.hwid && lic.hwid !== hwid) {
    log('activate.hwid_mismatch', { key: lic.key, hwid, detail: { bound: lic.hwid } })
    return {
      ok: false,
      code: 'HWID_MISMATCH',
      message: 'LICENCA VINCULADA A OUTRA MAQUINA - RESET NECESSARIO'
    }
  }

  const pwError = checkPassword(lic, password)
  if (pwError) return pwError

  const fresh = findByKey(lic.key)

  if (!fresh.hwid) {
    db.prepare('UPDATE licenses SET hwid = ?, activated_at = ?, last_seen_at = ? WHERE id = ?').run(
      hwid,
      now(),
      now(),
      fresh.id
    )
    log('activate.bound', { key: fresh.key, hwid, detail: meta })
  } else {
    db.prepare('UPDATE licenses SET last_seen_at = ? WHERE id = ?').run(now(), fresh.id)
  }

  return { ok: true, code: 'ACTIVATED', license: findByKey(fresh.key) }
}

export function verify(key, hwid, password = '') {
  const lic = findByKey(key)
  if (!lic) return { ok: false, code: 'INVALID_KEY', message: 'Chave nao encontrada.' }

  const status = effectiveStatus(lic)
  if (status === 'revoked') return { ok: false, code: 'REVOKED', message: 'Chave revogada.' }
  if (status === 'expired') return { ok: false, code: 'EXPIRED', message: 'Licenca expirada.' }
  if (lic.hwid && lic.hwid !== hwid) {
    return { ok: false, code: 'HWID_MISMATCH', message: 'Licenca vinculada a outra maquina.' }
  }

  const pwError = checkPassword(lic, password)
  if (pwError) return pwError

  db.prepare('UPDATE licenses SET last_seen_at = ? WHERE id = ?').run(now(), lic.id)
  return { ok: true, code: 'OK', license: findByKey(lic.key) }
}

/** Suporte: define uma senha nova para o cliente. */
export function setPassword(key, password) {
  const lic = findByKey(key)
  if (!lic) return { ok: false, message: 'Chave nao encontrada.' }
  if (!isValidPassword(password)) {
    return { ok: false, message: 'A senha precisa ter no minimo 6 caracteres.' }
  }
  db.prepare('UPDATE licenses SET password_hash = ?, password_set_at = ? WHERE id = ?').run(
    hashPassword(password),
    now(),
    lic.id
  )
  log('license.password_set_by_staff', { key: lic.key })
  return { ok: true, message: `Senha de ${lic.key} definida.` }
}

/** Suporte: limpa a senha (o cliente cria uma nova no proximo login). */
export function clearPassword(key) {
  const lic = findByKey(key)
  if (!lic) return { ok: false, message: 'Chave nao encontrada.' }
  db.prepare('UPDATE licenses SET password_hash = NULL, password_set_at = NULL WHERE id = ?').run(lic.id)
  log('license.password_cleared', { key: lic.key })
  return {
    ok: true,
    message: `Senha de ${lic.key} apagada. O cliente cria uma nova no proximo login.`
  }
}

export function resetHwid(key) {
  const lic = findByKey(key)
  if (!lic) return { ok: false, message: 'Chave nao encontrada.' }
  db.prepare('UPDATE licenses SET hwid = NULL, activated_at = NULL WHERE id = ?').run(lic.id)
  log('license.hwid_reset', { key: lic.key, detail: { previous: lic.hwid } })
  return { ok: true, message: `HWID liberado para ${lic.key}` }
}

export function setRevoked(key, revoked = true) {
  const lic = findByKey(key)
  if (!lic) return { ok: false, message: 'Chave nao encontrada.' }
  db.prepare('UPDATE licenses SET status = ? WHERE id = ?').run(revoked ? 'revoked' : 'active', lic.id)
  log(revoked ? 'license.revoked' : 'license.unrevoked', { key: lic.key })
  return { ok: true, message: `${lic.key} -> ${revoked ? 'revogada' : 'ativa'}` }
}

export function bindDiscord(key, discordId, discordTag = null) {
  const lic = findByKey(key)
  if (!lic) return { ok: false, message: 'Chave nao encontrada.' }
  db.prepare('UPDATE licenses SET discord_id = ?, discord_tag = ? WHERE id = ?').run(
    discordId || null,
    discordTag,
    lic.id
  )
  return { ok: true, message: 'Discord vinculado.' }
}

export function licensesOfDiscord(discordId) {
  return db
    .prepare('SELECT * FROM licenses WHERE discord_id = ? ORDER BY created_at DESC')
    .all(discordId)
}

export function listLicenses({ search = '', limit = 100, offset = 0 } = {}) {
  const like = `%${String(search).toUpperCase()}%`
  return db
    .prepare(
      `SELECT l.*, u.username, u.global_name, u.avatar
         FROM licenses l LEFT JOIN users u ON u.discord_id = l.discord_id
        WHERE UPPER(l.key) LIKE ? OR IFNULL(l.discord_id,'') LIKE ? OR IFNULL(u.username,'') LIKE ?
        ORDER BY l.created_at DESC LIMIT ? OFFSET ?`
    )
    .all(like, `%${search}%`, `%${search}%`, limit, offset)
}

// ---------- perfis do Discord ----------

export function upsertUser({ id, username, globalName, avatar }) {
  if (!id) return
  db.prepare(
    `INSERT INTO users (discord_id, username, global_name, avatar, updated_at)
     VALUES (?,?,?,?,?)
     ON CONFLICT(discord_id) DO UPDATE SET
       username = excluded.username,
       global_name = excluded.global_name,
       avatar = excluded.avatar,
       updated_at = excluded.updated_at`
  ).run(id, username || null, globalName || null, avatar || null, now())
}

export function getUser(discordId) {
  if (!discordId) return null
  return db.prepare('SELECT * FROM users WHERE discord_id = ?').get(discordId)
}

export function stats() {
  const total = db.prepare('SELECT COUNT(*) c FROM licenses').get().c
  const active = db.prepare("SELECT COUNT(*) c FROM licenses WHERE status='active'").get().c
  const revoked = db.prepare("SELECT COUNT(*) c FROM licenses WHERE status='revoked'").get().c
  const bound = db.prepare('SELECT COUNT(*) c FROM licenses WHERE hwid IS NOT NULL').get().c
  const orders = db.prepare("SELECT COUNT(*) c FROM orders WHERE status='approved'").get().c
  return { total, active, revoked, bound, approvedOrders: orders }
}
