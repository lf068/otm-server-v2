import { config } from '../config.js'
import { activate, verify, findByKey, effectiveStatus } from '../services/licenses.js'
import { syncProfile, profilePayload } from '../services/discord-profile.js'

async function withProfile(result) {
  const base = {
    offlineGraceDays: config.license.offlineGraceDays,
    serverTime: Date.now()
  }

  if (!result.ok) return { ...result, ...base }

  const lic = result.license
  const license = {
    key: lic.key,
    plan: lic.plan,
    status: effectiveStatus(lic),
    expiresAt: lic.expires_at,
    activatedAt: lic.activated_at,
    bound: !!lic.hwid,
    hasPassword: !!lic.password_hash
  }

  const discordId = lic.discord_id
  if (!discordId) return { ...result, license, profile: null, ...base }

  let profile = profilePayload(discordId)
  if (!profile) {
    await syncProfile(discordId)
    profile = profilePayload(discordId)
  }

  return { ...result, license, profile, ...base }
}

export default async function publicRoutes(app) {
  app.get('/api/health', async () => ({ ok: true, name: 'OTM License Server', ts: Date.now() }))

  /**
   * Chamado quando o cliente clica em "Ativar" no app.
   * Vincula o HWID na primeira vez.
   */
  app.post('/api/activate', async (req, reply) => {
    const { key, hwid, password, version } = req.body || {}
    if (!key || !hwid) {
      return reply.code(400).send({ ok: false, code: 'BAD_REQUEST', message: 'Informe a chave.' })
    }
    const result = activate(key, String(hwid), password ? String(password) : '', { version })
    return reply.send(await withProfile(result))
  })

  /**
   * Chamado a cada abertura do app (valida HWID + senha + devolve perfil atualizado).
   */
  app.post('/api/verify', async (req, reply) => {
    const { key, hwid, password } = req.body || {}
    if (!key || !hwid) {
      return reply.code(400).send({ ok: false, code: 'BAD_REQUEST', message: 'Informe a chave.' })
    }
    const result = verify(key, String(hwid), password ? String(password) : '')
    return reply.send(await withProfile(result))
  })

  /** Perfil publico do dono da chave (nome + avatar). */
  app.get('/api/profile/:key', async (req, reply) => {
    const lic = findByKey(req.params.key)
    if (!lic) return reply.code(404).send({ ok: false, message: 'Chave nao encontrada.' })
    if (!lic.discord_id) return reply.send({ ok: true, profile: null })

    let profile = profilePayload(lic.discord_id)
    if (!profile) {
      await syncProfile(lic.discord_id)
      profile = profilePayload(lic.discord_id)
    }
    return reply.send({ ok: true, profile })
  })
}
