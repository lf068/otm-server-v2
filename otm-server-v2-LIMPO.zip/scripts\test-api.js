/**
 * Teste rapido da API (chave + senha + HWID). Rode com o servidor ligado:
 *   node scripts/test-api.js http://localhost:8080 SEU_ADMIN_TOKEN
 */
const BASE = process.argv[2] || 'http://localhost:8080'
const TOKEN = process.argv[3] || 'TROQUE-ESTE-TOKEN-AGORA'

let pass = 0
let fail = 0

const api = async (path, { method = 'GET', body, admin = false } = {}) => {
  const res = await fetch(BASE + path, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(admin ? { 'x-admin-token': TOKEN } : {})
    },
    body: body ? JSON.stringify(body) : undefined
  })
  return { status: res.status, json: await res.json().catch(() => null) }
}

const ok = (label, cond, extra = '') => {
  if (cond) pass++
  else fail++
  console.log(`${cond ? 'OK ' : 'XX '} ${label}${extra ? ' -> ' + extra : ''}`)
}

const KEY = (k, hwid, password) => ({ key: k, hwid, ...(password ? { password } : {}) })

const PW = 'senha12345'
const PW2 = 'outrasenha9'
const A = 'HWID-MAQUINA-A'
const B = 'HWID-MAQUINA-B'

async function main() {
  console.log(`\n=== Testando ${BASE} ===\n`)

  ok('health', (await api('/api/health')).json?.ok === true)

  const created = await api('/api/admin/keys', {
    method: 'POST',
    admin: true,
    body: { amount: 1, plan: 'lifetime' }
  })
  const key = created.json?.keys?.[0]
  ok('gerar chave', !!key, key)
  if (!key) return

  // ---------- primeira ativacao ----------
  const noPw = await api('/api/activate', { method: 'POST', body: KEY(key, A) })
  ok('chave nova exige senha', noPw.json?.code === 'NEED_PASSWORD', noPw.json?.message)

  const weak = await api('/api/activate', { method: 'POST', body: KEY(key, A, '123') })
  ok('senha curta recusada', weak.json?.code === 'WEAK_PASSWORD')

  const first = await api('/api/activate', { method: 'POST', body: KEY(key, A, PW) })
  ok('criar senha + ativar', first.json?.ok === true && first.json?.license?.bound === true)
  ok('servidor confirma a senha', first.json?.license?.hasPassword === true)

  // ---------- logins seguintes ----------
  const noPwAgain = await api('/api/activate', { method: 'POST', body: KEY(key, A) })
  ok('sem senha nao entra', noPwAgain.json?.code === 'PASSWORD_REQUIRED')

  const wrongPw = await api('/api/activate', { method: 'POST', body: KEY(key, A, PW2) })
  ok('senha errada bloqueada', wrongPw.json?.code === 'WRONG_PASSWORD')

  const good = await api('/api/activate', { method: 'POST', body: KEY(key, A, PW) })
  ok('senha certa entra', good.json?.ok === true)

  const ver = await api('/api/verify', { method: 'POST', body: KEY(key, A, PW) })
  ok('verify com senha certa', ver.json?.ok === true && ver.json?.code === 'OK')

  const verWrong = await api('/api/verify', { method: 'POST', body: KEY(key, A, PW2) })
  ok('verify com senha errada', verWrong.json?.code === 'WRONG_PASSWORD')

  // ---------- HWID ----------
  const otherPc = await api('/api/activate', { method: 'POST', body: KEY(key, B, PW) })
  ok('outra maquina bloqueada', otherPc.json?.code === 'HWID_MISMATCH')

  const fake = await api('/api/activate', { method: 'POST', body: KEY('OTM-XXXX-XXXX-XXXX-XXXX', A, PW) })
  ok('chave inexistente', fake.json?.code === 'INVALID_KEY')

  // ---------- suporte ----------
  const set = await api('/api/admin/set-password', {
    method: 'POST',
    admin: true,
    body: { key, password: PW2 }
  })
  ok('suporte define senha nova', set.json?.ok === true)

  const entersWithNew = await api('/api/activate', { method: 'POST', body: KEY(key, A, PW2) })
  ok('cliente entra com a senha nova', entersWithNew.json?.ok === true)

  const oldPw = await api('/api/activate', { method: 'POST', body: KEY(key, A, PW) })
  ok('senha antiga para de funcionar', oldPw.json?.code === 'WRONG_PASSWORD')

  const clear = await api('/api/admin/reset-password', { method: 'POST', admin: true, body: { key } })
  ok('suporte apaga a senha', clear.json?.ok === true)

  const afterClear = await api('/api/activate', { method: 'POST', body: KEY(key, A) })
  ok('depois de apagar, pede senha nova', afterClear.json?.code === 'NEED_PASSWORD')

  const recreate = await api('/api/activate', { method: 'POST', body: KEY(key, A, PW) })
  ok('cliente cria a senha de novo', recreate.json?.ok === true)

  // ---------- reset de HWID ----------
  const reset = await api('/api/admin/reset-hwid', { method: 'POST', admin: true, body: { key } })
  ok('reset de HWID', reset.json?.ok === true)

  const newPc = await api('/api/activate', { method: 'POST', body: KEY(key, B, PW) })
  ok('ativa no PC novo com a mesma senha', newPc.json?.ok === true)

  // ---------- revogacao ----------
  const revoke = await api('/api/admin/revoke', { method: 'POST', admin: true, body: { key, revoked: true } })
  ok('revogar', revoke.json?.ok === true)

  const blocked = await api('/api/activate', { method: 'POST', body: KEY(key, B, PW) })
  ok('revogada nao entra nem com senha certa', blocked.json?.code === 'REVOKED')

  // ---------- admin ----------
  const noToken = await api('/api/admin/stats')
  ok('admin sem token -> 401', noToken.status === 401)

  const st = await api('/api/admin/stats', { admin: true })
  ok('stats com token', st.json?.ok === true && typeof st.json?.total === 'number')

  console.log(`\n=== ${pass} passaram, ${fail} falharam ===\n`)
  process.exitCode = fail ? 1 : 0
}

main().catch((e) => {
  console.error('erro no teste:', e)
  process.exitCode = 1
})
